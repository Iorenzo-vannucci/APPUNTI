### Chord routing
Quando mandiamo in esecuzione i dispatcher, il primo dispatcher che viene avviato e' solo e diventa il dispatcher seed peer, quello a cui si collegheranno gli altri dispatcher per entrare nel ring. Quando un dispatcher si aggiunge al ring, gli viene assegnato un id calcolato tramite l'hash dell'indirizzo ip e della porta.  
L'anello Chord puo' essere visto come un anello di numeri, nel nostro caso m di default e' 8, quindi l'anello va da 0 a 2^8-1 = 255, cio'
significa che abbiamo 256 possibili id (o data item), un data item e' gestito dal dispatcher il cui id e' il successore del data item, quindi
e' gestito dal dispatcher con l'id piu' piccolo tra quelli maggiori o uguali all'id del data item, se arriviamo alla fine dell'anello senza trovare un dispatcher valido, facciamo wrap-around e continuiamo la ricerca dall'id 0 fino al primo dispatcher che incontriamo.
In seguito il client mandera' i task non piu a tutti i dispatcher del gruppo, ma solo al dispatcher successore del task, quindi ad ogni task verra' associato un id calcolato tramite l'hash del task e del task id, e il dispatcher successore di questo id ricevera' il task. Ogni dispatcher mantiene anche una "finger table" che gli consente di saltare direttamente a nodi piu' lontani nell'anello, accelerando la ricerca del successore. La ricerca del successore viene effettuata ricorsivamente, il funzionamento della finger table e' cosi':
Dato un nodo n e supponiamo m=5 bit, la finger table sara' composta da 5 righe, di cui ogni riga corrisponde ad un salto di lunghezza pari a:
id_dispatcher_attuale + 2^(riga-1)
nel caso in cui si superi l'ultimo id possibile, si fa wrap-around e si continua la ricerca dall'id 0 fino al primo dispatcher che si incontra.
Es:
Finger[1]: start=7  → Nodo 12  (salto corto)
Finger[2]: start=8  → Nodo 12
Finger[3]: start=10 → Nodo 12
Finger[4]: start=14 → Nodo 20  (salto medio)
Finger[5]: start=22 → Nodo 28  (salto lungo!)

Grazie alla finger table troviamo il successore del task in modo ottimale con efficienza O(log N), a differenza della ricerca lineare che altrimenti dovremmo fare con O(N).

### Cambiamenti fatti dal maestro Giordano:
- Implementato routing Chord, anziche' avere una lista hardcoded dei dispatcher, abbiamo un solo endpoint a cui inviamo la task e che provvedera' ad affidarla al nodo successore alla task tramite implementazione di finger table;
- Implementato heartbeat protocol per controllare l'attivita' dei nodi e mantenerli sincronizzati.