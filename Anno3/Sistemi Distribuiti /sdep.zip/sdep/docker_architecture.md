# Architettura di Dockerizzazione SDEP

Il sistema utilizza una topologia a due livelli gestita tramite container Docker:
1. **Livello di Rete (Dispatcher)**: Nodi permanenti che compongono l'anello Chord ed espongono il servizio.
2. **Livello di Esecuzione (Sandbox)**: Container effimeri (creati al volo e subito distrutti) che eseguono codice non fidato in isolamento.

Per gestire questa architettura è stato implementato il pattern **Docker-out-of-Docker (DooD)**. A differenza del *Docker-in-Docker* (che esegue un demone Docker interno annidato), il DooD fa sì che i container dispatcher utilizzino il demone Docker della macchina *host* per "evocare" i container sandbox, che nascono quindi come "fratelli" (siblings) e non come "figli" all'interno del dispatcher.

Ecco un'analisi dettagliata dei tre file chiave che abilitano questa struttura.

---

### 1. `Dockerfile` (La Sandbox di Esecuzione)
Questo file definisce l'immagine per i container "usa e getta" (`edgerev-sandbox`) in cui verrà effettivamente valutato il task mandato dal client.

```dockerfile
FROM python:3.10

#utente no privilegi
RUN useradd -m stupid_user 
WORKDIR /app
USER stupid_user
CMD ["python", "-u", "task.py"]
```

> [!IMPORTANT]
> **Isolamento e Sicurezza**: L'obiettivo principale di questo container è la sicurezza. Viene creato un utente non privilegiato (`stupid_user`) e la direttiva `USER` assicura che il payload Python fornito dal client venga eseguito **senza privilegi di root**. 
> - Il file `task.py` non è presente nell'immagine, ma verrà montato a runtime come volume dal dispatcher.
> - L'opzione `-u` forza Python a stampare l'output nel buffer standard senza ritardi.

---

### 2. `Dockerfile.dispatcher` (Il Nodo Chord)
Questo file definisce l'immagine (`sdep-dispatcher-*`) per i nodi dell'anello DHT.

```dockerfile
FROM python:3.10-slim

# Docker CLI per lanciare i container sandbox tramite socket mount
RUN apt-get update && \
    apt-get install -y --no-install-recommends ca-certificates curl && \
    # ... installazione chiavi repo ufficiali Docker ...
    apt-get install -y --no-install-recommends docker-ce-cli && \
    rm -rf /var/lib/apt/lists/*

WORKDIR /app
COPY chord.py registry.py dispatcher.py ./

ENV PYTHONUNBUFFERED=1
CMD ["python", "dispatcher.py"]
```

> [!NOTE]
> **Perché installare la CLI di Docker in un container Docker?**
> Dal momento che i dispatcher sono containerizzati, di base non hanno il comando `docker`. Invece di installare un intero demone (che sarebbe pesante e pericoloso), installiamo **solo la CLI** (`docker-ce-cli`). Questo permette al dispatcher di invocare comandi come `docker run ... edgerev-sandbox`, ma la reale esecuzione verrà demandata al demone dell'host (vedi il mount del socket in `docker-compose`).
> 
> L'istruzione `ENV PYTHONUNBUFFERED=1` è essenziale: senza di essa, in un ambiente containerizzato i `print()` di Python verrebbero bufferizzati e si vedrebbero i log solo in ritardo o all'uscita del programma.

---

### 3. `docker-compose.yml` (L'Orchestrazione)
Questo file dichiara l'infrastruttura di rete, instanziando 3 dispatcher (un *seed* e due *peer*) su una rete isolata.

```yaml
services:
  dispatcher-seed:
    build:
      context: .
      dockerfile: Dockerfile.dispatcher
    ports:
      - "5005:5005"
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock
      - ./shared_tasks:/app/shared_tasks
    environment:
      - HOST_SHARED_TASKS=${PWD}/shared_tasks
      - LOCAL_SHARED_TASKS=/app/shared_tasks
    command: python dispatcher.py 5005 dispatcher-seed
    networks:
      - chord-net
# ... (configurazioni quasi identiche per dispatcher-2 e dispatcher-3) ...
```

#### Elementi Chiave del Compose:

- **Il Socket Docker (`/var/run/docker.sock`)**:
  > [!CAUTION]
  > Mappando `/var/run/docker.sock:/var/run/docker.sock`, colleghiamo la CLI interna del `dispatcher` direttamente al motore Docker dell'host (Pattern DooD). Quando `dispatcher.py` esegue uno script `subprocess.run(["docker", "run", ...])`, in realtà sta dicendo al demone host di accendere un nuovo container sandbox parallelamente ai dispatcher esistenti.

- **Il Volume Condiviso (`shared_tasks`)**:
  Per passare il codice del task dal Dispatcher alla Sandbox senza rischiare problemi di stream via `stdin`, usiamo un volume mappato sia sull'host (nella directory corrente) sia all'interno dei container in `/app/shared_tasks`.
  - Il Dispatcher scrive il payload in `/app/shared_tasks/task_123.py`.
  - Attraverso le variabili `HOST_SHARED_TASKS`, il dispatcher sa indicare al demone host dove trovare fisicamente questo file sul computer fisico per mapparlo direttamente dentro alla Sandbox.

- **La Rete Isolata (`chord-net`)**:
  Tutti i dispatcher girano su una rete `bridge` interna chiamata `chord-net`. Questo significa che possono parlarsi tra loro usando direttamente i loro nomi (es. `dispatcher-seed`, `dispatcher-2`) bypassando il DNS dell'host, formando così un anello Chord completamente autonomo e chiuso al mondo esterno.

- **Il port mapping**:
  Il port mapping viene utilizzato per esporre le porte dei dispatcher all'host. Ad esempio, `"5005:5005"` significa che la porta 5005 del container è mappata sulla porta 5005 dell'host. In questo modo, possiamo accedere ai dispatcher dall'esterno del container, avviando l'insieme dei container inoltre notiamo che tutti i container fanno riferimento alla loro porta 5005, ma sono accessibili dall'host tutti da porte diverse.