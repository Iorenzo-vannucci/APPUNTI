import socket, threading, json, subprocess, os, sys, time, hashlib, signal
from chord import ChordNode

HOST = '0.0.0.0'
PORT = 5005
BUFFER_SIZE = 4096

CHORD_LOCK = threading.Lock()
NODO_CHORD = None

TASK_CACHE = {}
TASK_CACHE_LOCK = threading.Lock()

ERRORE_PREFISSI = ("Errore:", "Runtime Error", "Errore interno")

SHARED_TASKS_LOCAL = os.environ.get("LOCAL_SHARED_TASKS", os.path.join(os.getcwd(), "shared_tasks"))
SHARED_TASKS_HOST = os.environ.get("HOST_SHARED_TASKS", SHARED_TASKS_LOCAL)
os.makedirs(SHARED_TASKS_LOCAL, exist_ok=True)


def is_risultato_valido(result):
    """Restituisce True solo se il risultato è un output valido (non un errore)."""
    return result is not None and not any(result.startswith(p) for p in ERRORE_PREFISSI)


def send_json(sock, msg):
    sock.sendall((json.dumps(msg) + "\n").encode('utf-8'))


def rpc_call(ip, porta, payload):
    """Invia un messaggio RPC e restituisce la risposta JSON."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(5.0)
    try:
        sock.connect((ip, porta))
        send_json(sock, payload)
        risposta = sock.makefile("r", encoding="utf-8").readline()
        return json.loads(risposta) if risposta else None
    finally:
        sock.close()


def rpc_find_successor(ip, porta, key):
    """Trova iterativamente il successore di key seguendo gli hop."""
    for _ in range(30):
        try:
            r = rpc_call(ip, porta, {"type": "FIND_SUCCESSOR", "key": key})
            if r is None:
                return None
            if r.get("found"):
                return r["node"]
            ip, porta = r["node"]["ip"], r["node"]["porta"]
        except Exception as e:
            print(f"[RPC] find_successor fallito per {ip}:{porta}: {e}")
            return None
    return None


def rpc_is_alive(ip, porta):
    try:
        r = rpc_call(ip, porta, {"type": "BEAT", "ip": ip, "porta": porta})
        return r is not None and r.get("status") == "OK"
    except Exception:
        return False


# === Stabilizzazione periodica ===

def stabilization_loop():
    while True:
        time.sleep(5)
        if NODO_CHORD is None:
            continue
        try:
            with CHORD_LOCK:
                succ = NODO_CHORD.successor
                self_ref = NODO_CHORD.ref()

            if succ["id"] != self_ref["id"] and not rpc_is_alive(succ["ip"], succ["porta"]):
                raise OSError(f"Successore {succ['id']} non raggiungibile")

            pred_of_succ = rpc_call(succ["ip"], succ["porta"], {"type": "GET_PREDECESSOR"})
            pred_of_succ = pred_of_succ.get("predecessor") if pred_of_succ else None
            sl = rpc_call(succ["ip"], succ["porta"], {"type": "GET_SUCCESSOR_LIST"})
            sl = sl.get("successor_list", []) if sl else []

            with CHORD_LOCK:
                if NODO_CHORD.stabilize(pred_of_succ, sl):
                    print(f"[Stabilize] Successore aggiornato a {NODO_CHORD.successor['id']}")
                succ_attuale = NODO_CHORD.successor

            rpc_call(succ_attuale["ip"], succ_attuale["porta"],
                     {"type": "NOTIFY", "node": self_ref})

            # fix_fingers
            with CHORD_LOCK:
                i = random.randint(0, NODO_CHORD.m - 1)
                start = (NODO_CHORD.id + 2**i) % (2**NODO_CHORD.m)
                sf, _ = NODO_CHORD.find_successor(start)

            if sf:
                if sf["id"] != NODO_CHORD.id:
                    result = rpc_find_successor(sf["ip"], sf["porta"], start)
                    with CHORD_LOCK:
                        if result:
                            NODO_CHORD.finger[i] = result
                else:
                    with CHORD_LOCK:
                        NODO_CHORD.finger[i] = sf

            # check_predecessor
            with CHORD_LOCK:
                pred = NODO_CHORD.predecessor
            if pred and pred["id"] != NODO_CHORD.id and not rpc_is_alive(pred["ip"], pred["porta"]):
                print(f"[Stabilize] Predecessore {pred['id']} morto. Azzero.")
                with CHORD_LOCK:
                    NODO_CHORD.predecessor = None

        except OSError:
            print(f"[Stabilize] Successore {succ['id']} sembra morto.")
            with CHORD_LOCK:
                if NODO_CHORD.remove_successor():
                    print(f"[Stabilize] Promosso: {NODO_CHORD.successor['id']}")
        except Exception as e:
            print(f"[Stabilize] Errore: {e}")


import random  # per fix_fingers


# === Routing e task ===

def trova_repliche(k=3):
    with CHORD_LOCK:
        my_id = NODO_CHORD.id
        return [{"ip": n["ip"], "porta": n["porta"]}
                for n in NODO_CHORD.successor_list if n["id"] != my_id][:k-1]


def inoltra_task(client_socket, request, ip_hop, porta_hop, retry=3):
    """Inoltra il task al prossimo hop e fa relay delle risposte."""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(15.0)
        sock.connect((ip_hop, porta_hop))
        send_json(sock, request)
        settled = False
        for linea in sock.makefile('r', encoding='utf-8'):
            risposta = json.loads(linea)
            send_json(client_socket, risposta)
            if risposta.get("status") == "SETTLED":
                settled = True
                break
        sock.close()
        if not settled:
            raise OSError("Connessione chiusa prematuramente senza SETTLED")
    except OSError:
        task_id = request.get("task_id", "Unknown")
        if retry > 0:
            print(f"[Routing] Fallito inoltro a {ip_hop}:{porta_hop}, retry...")
            with CHORD_LOCK:
                if NODO_CHORD.successor["ip"] == ip_hop and NODO_CHORD.successor["porta"] == porta_hop:
                    NODO_CHORD.remove_successor()
                next_node, _ = NODO_CHORD.find_successor(request.get("task_hash"))
            if next_node and next_node["id"] != NODO_CHORD.id:
                inoltra_task(client_socket, request, next_node["ip"], next_node["porta"], retry - 1)
            else:
                send_json(client_socket, {"status": "SETTLED", "task_id": task_id,
                                          "result": "Errore: nodo irraggiungibile"})
        else:
            send_json(client_socket, {"status": "SETTLED", "task_id": task_id,
                                      "result": "Errore: nodo irraggiungibile dopo 3 tentativi"})
    except Exception as e:
        send_json(client_socket, {"status": "SETTLED", "task_id": request.get("task_id", "Unknown"),
                                  "result": f"Errore nel routing: {e}"})


def contatta_replica(ip, porta, request, risultati, lock):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(45.0)
        sock.connect((ip, porta))
        send_json(sock, request)
        for linea in sock.makefile('r', encoding='utf-8'):
            r = json.loads(linea)
            if r.get("status") == "SETTLED":
                with lock:
                    risultati.append(r.get("result"))
                break
        sock.close()
    except Exception as e:
        print(f"[Coordinatore] Errore replica {ip}:{porta} → {e}")


def propaga_cache(code_hash, risultato, repliche, entry_point):
    """Propaga il risultato alle repliche e all'entry-point (fire-and-forget)."""
    destinatari = list(repliche)
    if entry_point:
        with CHORD_LOCK:
            my_id = NODO_CHORD.id
        if entry_point["id"] != my_id:
            destinatari.append({"ip": entry_point["ip"], "porta": entry_point["porta"]})

    msg = {"type": "CACHE_STORE", "code_hash": code_hash, "result": risultato}
    for dest in destinatari:
        def invia(ip=dest["ip"], porta=dest["porta"]):
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(3.0)
                s.connect((ip, porta))
                send_json(s, msg)
                s.close()
            except Exception:
                pass
        threading.Thread(target=invia, daemon=True).start()


def esegui_sandbox(task_id, payload_code):
    """Esecuzione in sandbox Docker isolata."""
    tid = threading.get_ident()
    filepath_local = os.path.join(SHARED_TASKS_LOCAL, f"task_{tid}.py")
    filepath_host = os.path.join(SHARED_TASKS_HOST, f"task_{tid}.py")
    container_name = f"edgerev_sandbox_{tid}"
    try:
        with open(filepath_local, "w") as f:
            f.write(payload_code)
        r = subprocess.run(
            ["docker", "run", "--rm", "--name", container_name,
             "-m", "500m", "--cpus", "0.5", "--network", "none",
             "-v", f"{filepath_host}:/app/task.py", "edgerev-sandbox"],
            capture_output=True, text=True, timeout=30.0)
        return r.stdout.strip() if r.returncode == 0 else f"Runtime Error nella Sandbox:\n{r.stderr.strip()}"
    except subprocess.TimeoutExpired:
        subprocess.run(["docker", "kill", container_name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return "Errore: Limite di tempo massimo superato (Possibile loop infinito)."
    except Exception as e:
        return f"Errore interno Worker: {e}"
    finally:
        if os.path.exists(filepath_local):
            os.remove(filepath_local)


def gestisci_task_con_routing(client_socket, client_address, request):
    """Gestisce un TASK/ROUTE con routing Chord, quorum e cache."""
    task_id = request.get("task_id", "Unknown")
    task_hash = request.get("task_hash")

    # Primo hop: calcoliamo hash dal codice
    if task_hash is None:
        with CHORD_LOCK:
            m = NODO_CHORD.m
        code = request.get("code", "")
        code_hash_hex = hashlib.sha1(code.encode()).hexdigest()
        task_hash = int(code_hash_hex, 16) % (2**m)
        request.update({"task_hash": task_hash, "code_hash": code_hash_hex, "type": "ROUTE"})
        with CHORD_LOCK:
            request["entry_point"] = NODO_CHORD.ref()

    print(f"[Routing] Task '{task_id}' (hash={task_hash}) da {client_address}")

    with CHORD_LOCK:
        responsabile = NODO_CHORD.is_responsible(task_hash)

    if responsabile:
        # Fast path: cache
        code_hash = request.get("code_hash")
        if code_hash:
            with TASK_CACHE_LOCK:
                cached = TASK_CACHE.get(code_hash)
            if cached is not None:
                print(f"[Cache] HIT code_hash={code_hash[:8]}...")
                send_json(client_socket, {"status": "SETTLED", "task_id": task_id, "result": cached, "cache_hit": True})
                client_socket.close()
                return

        # Slow path: sandbox + replicazione + quorum
        print(f"[Routing] Responsabile (ID={NODO_CHORD.id}). Coordinamento replicazione.")
        repliche = trova_repliche(k=3)
        risultati, lock, threads = [], threading.Lock(), []

        def esecuzione_locale():
            with lock:
                risultati.append(esegui_sandbox(task_id, request.get("code", "")))

        t = threading.Thread(target=esecuzione_locale)
        threads.append(t)
        t.start()

        req_replica = {**request, "type": "REPLICA_EXEC"}
        for rep in repliche:
            print(f"[Coordinatore] Replica → {rep['ip']}:{rep['porta']}")
            t = threading.Thread(target=contatta_replica, args=(rep['ip'], rep['porta'], req_replica, risultati, lock))
            threads.append(t)
            t.start()

        for t in threads:
            t.join()

        totale = len(repliche) + 1
        maggioranza = (totale // 2) + 1
        print(f"[Coordinatore] Risposte: {len(risultati)}/{totale}")

        if len(risultati) >= maggioranza:
            risultato_finale = max(set(risultati), key=risultati.count) if len(set(risultati)) > 1 else risultati[0]

            if code_hash and is_risultato_valido(risultato_finale):
                with TASK_CACHE_LOCK:
                    TASK_CACHE[code_hash] = risultato_finale
                print(f"[Cache] Salvato code_hash={code_hash[:8]}...")
                propaga_cache(code_hash, risultato_finale, repliche, request.get("entry_point"))
            elif risultato_finale:
                print(f"[Cache] NON cachato (errore): {risultato_finale[:60]}")

            send_json(client_socket, {"status": "SETTLED", "task_id": task_id, "result": risultato_finale})
        else:
            send_json(client_socket, {"status": "SETTLED", "task_id": task_id,
                                      "result": "Errore: Quorum repliche non raggiunto."})
        client_socket.close()
    else:
        # Inoltro al prossimo hop
        with CHORD_LOCK:
            prossimo, _ = NODO_CHORD.find_successor(task_hash)
        if prossimo:
            print(f"[Routing] Inoltro a nodo {prossimo['id']} ({prossimo['ip']}:{prossimo['porta']})")
            inoltra_task(client_socket, request, prossimo["ip"], prossimo["porta"])
        else:
            send_json(client_socket, {"status": "SETTLED", "task_id": task_id,
                                      "result": "Errore: nodo responsabile non trovato"})
        client_socket.close()


# === Registrazione nella rete ===

def registra_nodo_nella_rete(ip_annuncio, porta, seed_peers):
    global NODO_CHORD
    NODO_CHORD = ChordNode(ip_annuncio, porta, m=8)
    print(f"[Chord] Nodo creato: ID={NODO_CHORD.id} ({ip_annuncio}:{porta})")

    if not seed_peers:
        NODO_CHORD.join(None)
        print("[Chord] Primo nodo nell'anello.")
        return

    for ip_seed, porta_seed in seed_peers:
        for tentativo in range(1, 6):
            try:
                successore = rpc_find_successor(ip_seed, porta_seed, NODO_CHORD.id)
                if successore:
                    NODO_CHORD.join(successore)
                    print(f"[Chord] Join completato. Successore: {successore['id']}")
                    return
            except Exception as e:
                print(f"[Chord] Seed {ip_seed}:{porta_seed} (tentativo {tentativo}/5): {e}")
                if tentativo < 5:
                    time.sleep(2)

    print("[Chord] Nessun seed raggiungibile. Avvio come primo nodo.")
    NODO_CHORD.join(None)


# === Connection handler ===

def connection_handler(client_socket, client_address):
    try:
        client_socket.settimeout(5.0)
        request = json.loads(client_socket.recv(BUFFER_SIZE).decode('utf-8'))
        tipo = request.get("type", "TASK")

        # Handler Chord semplici (request-response)
        if tipo == "FIND_SUCCESSOR":
            with CHORD_LOCK:
                nodo, found = NODO_CHORD.find_successor(request["key"])
            send_json(client_socket, {"status": "OK", "node": nodo, "found": found})
        elif tipo == "GET_PREDECESSOR":
            with CHORD_LOCK:
                send_json(client_socket, {"status": "OK", "predecessor": NODO_CHORD.predecessor})
        elif tipo == "GET_SUCCESSOR":
            with CHORD_LOCK:
                send_json(client_socket, {"status": "OK", "successor": NODO_CHORD.successor})
        elif tipo == "GET_SUCCESSOR_LIST":
            with CHORD_LOCK:
                send_json(client_socket, {"status": "OK", "successor_list": list(NODO_CHORD.successor_list)})
        elif tipo == "NOTIFY":
            with CHORD_LOCK:
                aggiornato = NODO_CHORD.notify(request["node"])
            if aggiornato:
                print(f"[Chord] Predecessore aggiornato a {request['node']['id']}")
            send_json(client_socket, {"status": "OK"})
        elif tipo == "BEAT":
            send_json(client_socket, {"status": "OK"})
        elif tipo == "GET_RING":
            # Ricostruisce l'anello seguendo i successori
            with CHORD_LOCK:
                self_ref = NODO_CHORD.ref()
                current = NODO_CHORD.successor
            nodes, visited = [self_ref], {self_ref["id"]}
            while current and current["id"] not in visited:
                visited.add(current["id"])
                nodes.append(current)
                try:
                    r = rpc_call(current["ip"], current["porta"], {"type": "GET_SUCCESSOR"})
                    current = r.get("successor") if r else None
                except Exception:
                    break
            send_json(client_socket, {"status": "OK", "nodes": nodes})
        elif tipo == "CACHE_STORE":
            code_hash, result = request.get("code_hash"), request.get("result")
            if code_hash and is_risultato_valido(result):
                with TASK_CACHE_LOCK:
                    TASK_CACHE[code_hash] = result
                print(f"[Cache] Salvato code_hash={code_hash[:8]}... (propagazione)")
            send_json(client_socket, {"status": "OK"})
        elif tipo == "TASK_QUERY":
            code_hash = request.get("code_hash")
            with TASK_CACHE_LOCK:
                risultato = TASK_CACHE.get(code_hash) if code_hash else None
            if risultato is not None:
                print(f"[Cache] HIT code_hash={code_hash[:8]}.")
                send_json(client_socket, {"status": "FOUND", "task_id": request.get("task_id"), "result": risultato})
            else:
                send_json(client_socket, {"status": "NOT_FOUND", "task_id": request.get("task_id")})
        elif tipo == "REPLICA_EXEC":
            # Esecuzione replica sandbox
            task_id = request.get("task_id", "Unknown")
            risultato = esegui_sandbox(task_id, request.get("code", ""))
            send_json(client_socket, {"status": "SETTLED", "task_id": task_id, "result": risultato})
        elif tipo in ("ROUTE", "TASK"):
            # Routing Chord (TASK dal client o ROUTE da altro dispatcher)
            gestisci_task_con_routing(client_socket, client_address, request)
            return  # gestisci_task_con_routing chiude il socket
        else:
            send_json(client_socket, {"status": "ERROR", "message": f"Tipo sconosciuto: {tipo}"})

        client_socket.close()
    except Exception as e:
        print(f"Errore connessione da {client_address}: {e}")
        client_socket.close()


# === Main ===

def parse_args():
    porta = int(sys.argv[1]) if len(sys.argv) > 1 else PORT
    ip_annuncio = "127.0.0.1"
    seed_peers = []
    for arg in sys.argv[2:]:
        if ":" in arg:
            h, p = arg.rsplit(":", 1)
            seed_peers.append((h, int(p)))
        else:
            ip_annuncio = arg
    return porta, ip_annuncio, seed_peers


def dispatcher_server():
    threading.current_thread().name = "Dispatcher-Main"
    porta, ip_annuncio, seed_peers = parse_args()
    registra_nodo_nella_rete(ip_annuncio, porta, seed_peers)

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        server.bind((HOST, porta))
        server.listen(5)
        print(f"[Dispatcher-Main] Server in ascolto sulla porta {porta} (annuncio: {ip_annuncio}:{porta})...")
        threading.Thread(target=stabilization_loop, daemon=True, name="Stabilize").start()
        while True:
            cs, ca = server.accept()
            threading.Thread(target=connection_handler, args=(cs, ca), name=f"H-{ca[1]}").start()
    except KeyboardInterrupt:
        print("[Dispatcher-Main] Spegnimento.")
    finally:
        server.close()


if __name__ == "__main__":
    signal.signal(signal.SIGINT, lambda *_: sys.exit(0))
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    dispatcher_server()
