import hashlib
import random


class ChordNode:

    def __init__(self, ip, porta, m=8, r=3):
        self.ip = ip
        self.porta = porta
        self.m = m
        self.r = r
        self.id = int(hashlib.sha1(f"{ip}:{porta}".encode()).hexdigest(), 16) % (2**m)
        self.finger = [None] * m
        self.successor_list = [self.ref()]
        self.predecessor = None

    @property
    def successor(self):
        return self.successor_list[0] if self.successor_list else self.ref()

    def ref(self):
        return {"ip": self.ip, "porta": self.porta, "id": self.id}

    def _in_range(self, val, lo, hi, inclusive=True):
        """Controlla se val è nell'intervallo (lo, hi] (inclusive) o (lo, hi) (open) con wrap-around."""
        if lo == hi:
            return True if inclusive else val != lo
        if inclusive:
            return (lo < val <= hi) if lo < hi else (val > lo or val <= hi)
        return (lo < val < hi) if lo < hi else (val > lo or val < hi)

    def is_responsible(self, key):
        if self.predecessor is None:
            return True
        return self._in_range(key, self.predecessor["id"], self.id)

    def find_successor(self, key):
        if self._in_range(key, self.id, self.successor["id"]):
            return self.successor, True
        n_prime = self.closest_preceding_node(key)
        if n_prime["id"] == self.id:
            return self.successor, True
        return n_prime, False

    def closest_preceding_node(self, key):
        for i in range(self.m - 1, -1, -1):
            f = self.finger[i]
            if f and self._in_range(f["id"], self.id, key, inclusive=False):
                return f
        return self.ref()

    def join(self, successor_ref=None):
        if successor_ref is None:
            self.successor_list = [self.ref()]
            self.predecessor = self.ref()
            self.finger = [self.ref()] * self.m
        else:
            self.successor_list = [successor_ref]
            self.predecessor = None
            self.finger[0] = successor_ref

    def stabilize(self, successor_predecessor, successor_successor_list=None):
        x = successor_predecessor
        cambiato = False
        if x and x["id"] != self.id:
            if self._in_range(x["id"], self.id, self.successor["id"], inclusive=False):
                self.successor_list = [x] + self.successor_list
                self.finger[0] = x
                cambiato = True
        if successor_successor_list:
            new_list = [self.successor]
            for s in successor_successor_list:
                if s["id"] not in [n["id"] for n in new_list]:
                    new_list.append(s)
            self.successor_list = new_list[:self.r]
        return cambiato

    def remove_successor(self):
        if len(self.successor_list) > 1:
            self.successor_list.pop(0)
            self.finger[0] = self.successor_list[0]
            return True
        return False

    def notify(self, n_prime_ref):
        if self.predecessor is None or self._in_range(
                n_prime_ref["id"], self.predecessor["id"], self.id, inclusive=False):
            self.predecessor = n_prime_ref
            return True
        return False