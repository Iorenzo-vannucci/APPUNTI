import time

time.sleep(8)
for i in range (0,10):
    print("cipao")