import time

time.sleep(6)
for i in range (0,10):
    print("cipao")