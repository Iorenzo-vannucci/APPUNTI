import time

time.sleep(7)
for i in range (0,10):
    print("cipao")