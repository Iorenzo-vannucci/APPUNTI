### client.py
Il client invia task computazionali ad un entry-point del sistema e non fa altro, attende soltanto che il task venga processato e il risultato ritorni, il client ha a disposizione soltanto uno o piu' entry point (per questioni di fault tolerance, se un entry point non risponde, ne usiamo un altro), ma la struttura del sistema e' comunque trasparente ad esso poiche' il client si limita a mandare ad un nodo e ricevere una risposta.

## Funzioni:
- parse_endpoints: Semplicemente parsiamo gli argomenti da CLI che saranno gli endpoint da contattare per l'invio del task.
- invia_task: Dato l'ID della task, il payload e una lista di endpoint, proviamo a mandare la task ad uno di loro e a ricevere una risposta.

### chord.py 
Contiene la struttura dati e le funzioni relative al protocollo Chord, un ChordNode e' costituito da:
- Un id che e' il suo indirizzo numerico sull'anello (calcolato tramite hash)
- Una finger table che contiene puntatori al suo successore, al successore del suo successore, e cosi' via. Per essere piu' precisi, ogni entry i della finger table contiene l'indirizzo del successore di (id + 2^i) mod (2^m), dove m e' la dimensione dello spazio degli indirizzi (nel nostro caso 8)
- Il suo predecessore, ovvero il nodo che precede il successore del nodo corrente
- Il suo successore, ovvero il nodo che segue il nodo corrente
I nodi chord sono capaci di costruire la propria finger table a partire da una lista di nodi noti, che viene aggiornata ogni volta che un nuovo nodo viene aggiunto o rimosso e cosi' facendo aggiorniamo di volta in volta la finger table.

### dispatcher.py
File che controlla la logica dei nodi della rete Chord, andiamo a gestire lo scambio di messaggi tra i nodi della rete, la costruzione e l'aggiornamento delle finger table e della rete in se', gestiamo i seguenti messaggi:
- JOIN, un nuovo nodo si connette all'anello ed annuncia la sua presenza;
- LEAVE, un nodo lascia l'anello;
- GET_RING, un nodo chiede la lista dei nodi dell'anello;
- BEAT, protocollo heartbeat per controllare lo stato dei nodi;
- ROUTE, routing della task verso il nodo responsabile;
- REPLICA_EXEC, esegue il task sulle copie di backup per effettuare la replicazione;
- LEAVE, un nodo lascia l'anello, invocata solo quando il nodo esce volontariamente dall'anello (SIGINT/SIGTERM);
Quando il dispatcher riceve una task, si fa il routing verso il nodo designato come responsabile della task, quando la task arriva li, si esegue in sandbox docker e si invia il risultato al client, la task viene anche replicata su successore e predecessore del client per far si che in caso di fallimento di un nodo, il task possa essere eseguito su un altro nodo, alla fine si ha il risultato se si raggiunge un quorum, ossia se la maggioranza dei nodi a cui e' stato affidato il task rispondono con un risultato e non crashano.

## Funzioni:
- graceful_shutdown: Handler da sostituire agli handler di SIGINT e SIGTERM, quando riceve il segnale comunica agli altri nodi l'uscita volontaria del nodo dalla rete e lo spegne.
- send_json: Utility per mandare json tramite socket
- normalizza_nodo: Passare da tupla (ip, porta) a oggetto {'ip': ip, 'porta': porta}
- aggiungi_nodo: Aggiunge un nodo alla lista del nodo locale dei nodi, usa una lock per evitare concorrenza;
- rimuvovi_nodo: Come aggiungi_nodo, ma lo rimuove;
- lista_nodi: Elenca la lista locale dei nodi sempre con la lock;
- ricostruisci_finger_table: Usando la lista dei nodi, costruisce la finger table locale del nodo corrente, usa la funzione costruisci_finger_table della struttura dati ChordNode;
- sono_responsabile: Controlla se il nodo corrente e' responsabile per la chiave data, usa la funzione _in_intervallo della struttura dati ChordNode;
- trova_repliche: Trova i successori del nodo corrente per la replicazione;
- propaga_join: Propaga il JOIN a tutti i nodi tranne il nodo che ha inviato il JOIN;
- gestisci_leave: Gestisce il LEAVE, il nodo che esce notifica direttamente tutti i peer;
- gestisci_join: Gestisce il JOIN;
- gestisci_get_ring: Gestisce il GET_RING;
- gestisci_heartbeat: Gestisce il BEAT;
- gestisci_route: Gestisce il ROUTE;
- gestisci_replica_exec: Gestisce il REPLICA_EXEC; 
- heartbeat_monitor: Codice eseguito dal thread che monitora lo stato dei nodi e notifica l'uscita di un nodo in caso di fallimento;
- registra_nodo_nella_rete: Registra il nodo alla rete Chord facendo riferimento a un seed peer, a cui chiede la lista dei nodi per poi costruire la propria finger table;
- inoltra_task: Inoltra un qualsiasi tipo di richiesta ad un nodo, se non risponde lo rimuoviamo dall'anello, ricostruiamo la finger table e riproviamo con i suoi successori;
- gestisci_task_con_routing: Gestisce la task quando arriva in un nodo, se ancora non ha un task_id, lo calcoliamo e facciamo partire il routing
- contatta_replica: Funzione usata dal Coordinatore per contattare una replica per eseguire la task
- esegui_sandbox: Esegue la task nel sandbox docker
- worker_thread_logic: Thread worker che gestisce le richieste di esecuzione task, e coordina la replicazione del task;
- connection_handler: Thread che gestisce l'accoppiamento dei socket dei nodi, ricevendo i messaggi da essi ed eseguendo il protocollo stabilito.
- dispatcher_server: Funzione main che fa partire il thread del connection_handler, quello dell'heartbeat monitor e accetta connessioni in entrata.

### registry.py
File che contiene funzioni utili per l'invio dei messaggi e per il mantenimento della rete p2p.

### Dockerizzazione
I dispatcher sono containerizzati e siccome devono lanciare sandbox docker, devono avere accesso al socket docker, abbiamo usato un approccio che prevede di montare il socket docker all'interno del container del dispatcher per consentire questa operazione.
Le task sono depositate nella cartella shared_tasks che viene montata all'interno di ogni container in modo tale che i dispatcher possano accederci.
Il primo dispatcher lanciato funge da seed-dispatcher, i successivi faranno riferimento a lui per collegarsi all'anello, ma una volta che tutti i nodi sono collegati, ogni nodo puo' fare da entry point, raggiungendo effettivamente l'obiettivo di una rete p2p decentralizzata, poiche' non c'e' un server centrale a cui tutti i nodi devono fare riferimento.
Il deploy dei container e' coordinato dallo script deploy.sh, che prende come parametro il numero di dispatcher da lanciare e crea dinamicamente il file docker-compose.yml con tutti i servizi necessari.